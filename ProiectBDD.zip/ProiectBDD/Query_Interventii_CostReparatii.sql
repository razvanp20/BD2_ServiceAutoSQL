-- Afiseaza Masina cu Nr de interventii si Costul total al reparatiilor
-- viewul Cars -> Programari -> Interventii -> Facturi
-- Complexitate 7

CREATE OR ALTER VIEW vSumaReparatiiInterventii AS
SELECT 
    [Marca],
    [Model],
    [An_Fabricatie],
    SUM(Suma_Totala_Euro) AS Suma_Reparatii,
    COUNT(Suma_Totala_Euro) AS Nr_Interventii
FROM 
    [ServieAuto].[dbo].[vCars_Facuri]
GROUP BY 
    [Marca],
    [Model],
    [An_Fabricatie]



  
