--Afiseaza Angajatii si timpul si ii clasifica in functie de timpul lor pt repararea unei interventii
--Complexitate 7 

CREATE OR ALTER VIEW vTimpMediuInterventii AS
WITH Timp_Mediu_Interventii AS (
	SELECT 
		[EmploeeID],
		[Nume] AS Nume_Angajat,
		[Prenume] AS Prenume_Angajat,
		[ServiciuID],
		[Denumire] AS Tip_Interventie,
		AVG(CAST(Durata_Ore AS FLOAT)) AS Timp_Mediu
	FROM 
		[ServieAuto].[dbo].[vEmployees_to_Servicii]
	GROUP BY 
		[EmploeeID],
		[Nume],
		[Prenume],
		[ServiciuID],
		[Denumire]
)
SELECT 
    Nume_Angajat,
    Prenume_Angajat,
    Tip_Interventie,
    Timp_Mediu,
	CASE 
		WHEN Timp_Mediu < 1 THEN 'RAPID'
		WHEN Timp_Mediu BETWEEN 1 AND 3 THEN 'NORMAL'
		ELSE 'LENT'
	END AS Clasificare_Timp
FROM 
    Timp_Mediu_Interventii



