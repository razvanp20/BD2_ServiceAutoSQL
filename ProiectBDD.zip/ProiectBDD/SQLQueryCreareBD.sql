﻿USE ServieAuto
GO
DELETE FROM Facturi;
DELETE FROM Interventii;
DELETE FROM Programari;
DELETE FROM Employees;
DELETE FROM Servicii;
DELETE FROM Cars;
DELETE FROM Clienti;
INSERT INTO Employees (EmploeeID, Nume, Prenume, Post, Telefon, Salariu, Comision) VALUES
(1, 'Popescu', 'Mihai', 'Mechanic', '0741210778', 4000, 20.7),
(2, 'Titiroi', 'Andrei', 'Mechanic', '0720314556', 7000, 9.6),
(3, 'Barzoi', 'Andrada', 'Mechanic', '0756147124', 3500, 32.1),
(4, 'Anton', 'Ioana' , 'Mechanic', '0721452444', 4200, 14.9),
(5, 'Mihailescu', 'Andrei', 'Mechanic', '0722456723', 5500, 10.4),
(6, 'Păduraru', 'Ion', 'Mechanic', '0734567321',3300, 25.9),
(7, 'Gavrila', 'Adrian', 'Mechanic', '0721345672', 4650, 22.6),
(8, 'Moroianu', 'Sandu', 'Mechanic', '079828321', 4780, 28.4),
(9, 'Radu', 'Marian', 'Mechanic', '0765432109',5100, 17.3),
(101, 'Ciobanu', 'Ana', 'Receptionist', '0743322110', 3200, NULL),
(102, 'Cotleanu', 'Alina', 'Manager', '0743322110', 90000, NULL);



INSERT INTO Clienti (ClientID, Nume, Prenume, Telefon, Email) 
VALUES
(10, 'Popescu', 'Ion', '0741123456', 'ion.popescu@example.com'),
(11, 'Ionescu', 'Maria', '0722233445', 'maria.ionescu@example.com'),
(12, 'Georgescu', 'Andrei', '0733344556', 'andrei.georgescu@example.com'),
(13, 'Dumitrescu', 'Elena', '0744455667', 'elena.dumitrescu@example.com'),
(14, 'Vasilescu', 'Bogdan', '0711223344', 'bogdan.vasilescu@example.com'),
(15, 'Popa', 'Florin', '0761234567', 'florin.popa@example.com'),
(16, 'Iliescu', 'Vlad', '0722345678', 'vlad.iliescu@example.com'),
(17, 'Stan', 'Simona', '0743456789', 'simona.stan@example.com'),
(18, 'Grigorescu', 'Dana', '0714567890', 'dana.grigorescu@example.com'),
(19, 'Marin', 'Alex', '0735678901', 'alex.marin@example.com');

INSERT INTO Cars (CarID, ClientID, Marca, Model, An_Fabricatie, Nr_Inmatriculare) 
VALUES
(20, 10, 'Dacia', 'Duster', 2018, 'B-01-AAA'),
(21, 11, 'Volkswagen', 'Golf', 2015, 'B-02-BBB'),
(22, 12, 'Ford', 'Focus', 2017, 'B-03-CCC'),
(23, 13, 'Toyota', 'Corolla', 2019, 'B-04-DDD'),
(24, 14, 'BMW', 'X3', 2020, 'B-05-EEE'),
(25, 15, 'Opel', 'Astra', 2016, 'B-06-FFF'),
(26, 16, 'Hyundai', 'Tucson', 2018, 'B-07-GGG'),
(27, 17, 'Renault', 'Megane', 2019, 'B-08-HHH'),
(28, 18, 'Kia', 'Sportage', 2021, 'B-09-III'),
(29, 19, 'Mercedes', 'GLC', 2022, 'B-10-JJJ');


INSERT INTO Servicii (ServiciuID, Denumire, Pret_Euro) 
VALUES
(110, 'Schimb Ulei', 50),
(111, 'Verificare Tehnica', 30),
(112, 'Reparatie Frane', 100),
(113, 'Schimb Baterie', 80),
(114, 'Geometrie Roti', 60),
(115, 'Inlocuire Placute Frana', 150),
(116, 'Reparatie Ambreiaj', 200),
(117, 'Incarcare Freon', 100),
(118, 'Reparatie Motor', 500),
(119, 'Schimb Filtru Aer', 40);

INSERT INTO Programari (ProgramareID, ClientID, CarID, Data_Programare, Ora_Programare, Status_Reparatie) 
VALUES
(90, 10, 20, '2025-01-10', '09:00:00', NULL),
(91, 11, 21, '2025-01-11', '10:30:00', NULL),
(92, 12, 22, '2025-01-12', '11:00:00', NULL),
(93, 13, 23, '2025-01-13', '12:00:00', NULL),
(94, 14, 24, '2025-01-14', '13:30:00', NULL),
(95, 15, 25, '2025-01-15', '10:00:00', NULL),
(96, 16, 26, '2025-01-16', '11:30:00', NULL),
(97, 17, 27, '2025-01-17', '12:00:00', NULL),
(98, 18, 28, '2025-01-18', '13:00:00', NULL),
(99, 19, 29, '2025-01-19', '14:00:00', NULL),
(901, 15, 25, '2025-01-20', '14:00:00', NULL),
(902, 14, 24, '2025-01-20', '15:00:00', NULL);


INSERT INTO Interventii (InterventieID, ProgramareID, ServiciuID, EmploeeID, Durata_Ore) 
VALUES
(40, 90, 110, 1, 2),
(41, 91, 111, 2, 1.5),
(42, 92, 112, 3, 3),
(43, 93, 113, 4, 2),
(44, 94, 114, 5, 1),
(45, 95, 115, 6, 2.5),
(46, 96, 116, 7, 4),
(47, 97, 117, 8, 1.5),
(48, 98, 118, 9, 6),
(49, 99, 119, 7, 1),
(401, 901, 114, 4, 1),
(402, 902, 114, 2, 3);



INSERT INTO Facturi (FacturaID, InterventieID, Data_Factura, Suma_Totala_Euro) 
VALUES
(70, 40, '2025-01-15', 100),
(71, 41, '2025-01-16', 150),
(72, 42, '2025-01-17', 200),
(73, 43, '2025-01-18', 80),
(74, 44, '2025-01-19', 120),
(75, 45, '2025-01-20', 375),
(76, 46, '2025-01-21', 800),
(77, 47, '2025-01-22', 150),
(78, 48, '2025-01-23', 500),
(79, 49, '2025-01-24', 60),
(701, 401, '2025-01-24', 60),
(702, 402, '2025-01-24', 130);


SELECT * FROM Clienti;
SELECT * FROM Cars;
SELECT * FROM Employees;
SELECT * FROM Servicii;
SELECT * FROM Programari;
SELECT * FROM Interventii;
SELECT * FROM Facturi;

