--Afisare Interventia si timpul mediu de reparatie in functie de mecanici
--Complexitate = 4

CREATE OR ALTER VIEW vInterventieTimpMediu AS
SELECT 
    [Denumire] AS Tip_Interventie,
    AVG(CAST(Durata_Ore AS FLOAT)) AS Timp_Mediu
FROM 
    [ServieAuto].[dbo].[vEmployees_to_Servicii]
GROUP BY
    [Denumire]

