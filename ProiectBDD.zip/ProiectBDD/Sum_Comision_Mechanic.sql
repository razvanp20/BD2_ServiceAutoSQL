SELECT TOP (1000) [EmploeeID]
      ,[Nume]
      ,[Prenume]
      ,[Salariu]
	  ,SUM(Pret_Euro * Comision /100) AS Comision_Primit
  FROM [ServieAuto].[dbo].[vEmployees_to_Servicii]
  WHERE Post = 'Mechanic'
  GROUP BY [EmploeeID]
      ,[Nume]
      ,[Prenume]
      ,[Salariu]

  
