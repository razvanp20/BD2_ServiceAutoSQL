CREATE OR ALTER VIEW vw_Analiza_Clienti_Facturi AS
SELECT 
    ClientID,
    Nume AS Nume_Client, 
    Prenume AS Prenume_Client, 
    Marca, 
    Model, 
    COUNT(*) AS Numar_Facturi,
    SUM(Suma_Totala_Euro) AS Total_Plati,
    AVG(Suma_Totala_Euro) AS Valoare_Medie_Factura,
    CASE 
        WHEN SUM(Suma_Totala_Euro) < 500 THEN 'Bronze'
        WHEN SUM(Suma_Totala_Euro) BETWEEN 500 AND 1500 THEN 'Silver'
        ELSE 'Gold'
    END AS Clasificare_Client
FROM 
    [ServieAuto].[dbo].[vClienti_Facturi]
GROUP BY 
    ClientID, 
    Nume, 
    Prenume, 
    Marca, 
    Model;

