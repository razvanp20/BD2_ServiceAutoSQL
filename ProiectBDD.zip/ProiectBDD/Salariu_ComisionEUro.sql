-- "Comisioane" transforma comisionul din procent in Euro folosind tabela de servicii
-- Foloseste tabelele Employees -> Interventii -> Servicii
-- Complexitate 2 inner inner join + 2 = 4
--Afiseaza Salariul Angajatului cu tot cu comision

CREATE OR ALTER VIEW vSalariiComisioane AS
SELECT 
    [Nume],
    [Prenume],
    [Salariu],
    SUM(Comision * Pret_Euro / 100) AS Comision_Euro,
    [Salariu] + SUM(Comision * Pret_Euro / 100 * 5) AS Salariu_Final
FROM 
    [ServieAuto].[dbo].[vEmployees_to_Servicii]
GROUP BY 
    [Nume], [Prenume], [Salariu]



